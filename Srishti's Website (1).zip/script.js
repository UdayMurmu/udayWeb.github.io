let navpanel = document.querySelector("ul");
let menuBtn = document.querySelector(".fa-bars");

const showNav = () => {
navpanel.classList.toggle("show");
menuBtn.classList.toggle("add")
}
menuBtn.addEventListener('click',showNav);